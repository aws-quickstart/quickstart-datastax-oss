#! /bin/bash

ansible-playbook -v -u ubuntu -i /home/cassandra/ansible-hosts.cfg --private-key /home/ubuntu/.ssh/id_rsa /home/cassandra/os-config.yml
ansible-playbook -v -u ubuntu -i /home/cassandra/ansible-hosts.cfg --private-key /home/ubuntu/.ssh/id_rsa /home/cassandra/ebs-init.yml
ansible-playbook -v -u ubuntu -i /home/cassandra/ansible-hosts.cfg --private-key /home/ubuntu/.ssh/id_rsa /home/cassandra/cassandra-directories.yml
