#! /bin/bash

rm -rf /home/ubuntu/.ssh/id_rsa*
ssh-keygen -q -N "" -f /home/ubuntu/.ssh/id_rsa
sudo chown ubuntu:ubuntu /home/ubuntu/.ssh/id_rsa*
cat /home/ubuntu/.ssh/id_rsa.pub >> /home/ubuntu/.ssh/authorized_keys
export ANSIBLE_HOST_KEY_CHECKING=False
