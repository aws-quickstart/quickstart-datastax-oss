echo "Start DSE Deployment"
touch ~/_run
echo "Finish DSE Deployment"
